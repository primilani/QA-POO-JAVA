package Desafio.Guincho;

public interface Trajeto {

    // Interface para trajetos entre os bairros
        Integer getDistanciaEmKm();
}
