package Desafio.Guincho;

public enum EstadoConservacao {

    // Enum para estado de conservação
    NOVO, QUEBRADO;
}
