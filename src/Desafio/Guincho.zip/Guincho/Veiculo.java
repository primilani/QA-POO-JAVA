package Desafio.Guincho;

public interface Veiculo {

    // Interface para tipos de veículos
        TipoVeiculo getTipo();
        EstadoConservacao getEstado();


}
