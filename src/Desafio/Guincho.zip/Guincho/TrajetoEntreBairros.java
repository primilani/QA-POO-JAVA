package Desafio.Guincho;

public class TrajetoEntreBairros {

    private int distanciaEmKm;

    public TrajetoEntreBairros(int distanciaEmKm){
        this.distanciaEmKm = distanciaEmKm;
    }

    @Override
    public Integer getDistanciaEmKm(){
        return distanciaEmKm;
    }

}
