package Desafio.Guincho;

public enum TipoVeiculo {

    // Enum para tipos de veiculos
    CARRO, MINIVAN, ONIBUS, CAMINHAO;
}
