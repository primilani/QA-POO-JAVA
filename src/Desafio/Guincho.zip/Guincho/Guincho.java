package Desafio.Guincho;

public interface Guincho {

    // Interface para os tipos de guincho
        double calcularCustoDoDeslocamento(Trajeto trajeto);




}
